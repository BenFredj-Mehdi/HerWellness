
# loader.py - Load the model in your website
import os
import pickle
import json
import tempfile
import numpy as np
import faiss
from groq import Groq
from sentence_transformers import SentenceTransformer

class PregnancyVoiceAssistant:
    def __init__(self, model_path="./voice_pregnancy_model", groq_api_key=None):
        self.groq = Groq(api_key=groq_api_key or os.getenv("GROQ_API_KEY"))

        with open(f"{model_path}/config.json", "r") as f:
            self.config = json.load(f)

        # Load FAISS
        self.index = faiss.read_index(f"{model_path}/faiss_index.bin")

        # Load chunks
        with open(f"{model_path}/chunks.pkl", "rb") as f:
            self.chunks = pickle.load(f)

        # Load embedding model
        self.embedder = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

    def search(self, question, k=3):
        emb = self.embedder.encode([question])
        distances, indices = self.index.search(emb.astype('float32'), k)
        return "\n\n".join([self.chunks[i] for i in indices[0]])

    def respond(self, question):
        context = self.search(question)
        prompt = self.config["system_prompt"].format(context=context[:2000], question=question)

        completion = self.groq.chat.completions.create(
            model=self.config["model"],
            messages=[{"role": "user", "content": prompt}],
            temperature=self.config["temperature"]
        )
        return completion.choices[0].message.content

print("✅ Model loader ready!")
